pdflatex Carvajal_2013.tex 
bibtex Carvajal_2013
pdflatex Carvajal_2013.tex 
pdflatex Carvajal_2013.tex 
